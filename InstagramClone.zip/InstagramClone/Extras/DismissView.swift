//
//  DismissView.swift
//  InstagramClone
//
//  Created by Luciano Nicolini on 28/10/2022.
//

import SwiftUI

struct DismissView: View {
    @Environment(\.dismiss) var dismiss
    var body: some View {
        HStack {
            Spacer()
            Button(action: {
                dismiss()
            }, label: {
                Image(systemName: "arrow.backward")
            })
            .padding(.leading,12)
        }
    }
}

struct DismissView_Previews: PreviewProvider {
    static var previews: some View {
        DismissView()
    }
}
