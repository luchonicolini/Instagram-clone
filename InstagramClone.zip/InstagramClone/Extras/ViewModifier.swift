//
//  ViewModifier.swift
//  InstagramClone
//
//  Created by Luciano Nicolini on 26/10/2022.
//

import Foundation
import SwiftUI

// View modifier for the black buttons
struct Buttons: ViewModifier {
    func body(content: Content) -> some View {
        content
            .padding()
            .frame(width: 360,height: 49)
            //.frame(maxWidth: .infinity)
            .background(Color("button"))
            .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
    }
}


struct FlightDetailsMenu: ViewModifier {
    var height: Int
    
    func body(content: Content) -> some View {
        
        content
            .padding()
            .frame(maxWidth: .infinity)
            .frame(height: CGFloat(self.height))
            .background(Color.white)
            .clipShape(RoundedRectangle(cornerRadius: 15, style: .continuous))
            .padding(.horizontal, 25)
    }
}
