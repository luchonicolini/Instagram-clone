//
//  InstagramCloneApp.swift
//  InstagramClone
//
//  Created by Luciano Nicolini on 25/10/2022.
//

import SwiftUI
import Firebase
import FirebaseCore
import FacebookLogin

class AppDelegate: NSObject, UIApplicationDelegate {
  func application(_ application: UIApplication,
                   didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
    ApplicationDelegate.shared.application(application, didFinishLaunchingWithOptions: launchOptions)
    
      
      FirebaseApp.configure()
    return true
  }
}

@main
struct InstagramCloneApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) var delegate
    @StateObject var authenticationViewModel = AuthenticationViewModel()
    var body: some Scene {
        WindowGroup {
            if let _ = authenticationViewModel.user {
                TabViewCustom()
            } else {
                Login(authenticacionViewModel: authenticationViewModel)
                //TabViewCustom()
            }
        }
    }
}
