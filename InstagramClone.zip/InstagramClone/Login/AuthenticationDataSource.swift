//
//  AuthenticationDataSource.swift
//  InstagramClone
//
//  Created by Luciano Nicolini on 28/10/2022.
//

import Foundation
import FirebaseAuth

struct User {
    let email: String
}

final class AuthenticationDataSource {
    private let facebookAuthentication = FacebookAuthentication()

    func getCurrentUser() -> User? {
        guard let email = Auth.auth().currentUser?.email else {
            return nil
        }
        return .init(email: email)
    }
    
    func createNewUser(email: String, password: String, completionBlock: @escaping (Result<User, Error>) -> Void) {
        Auth.auth().createUser(withEmail: email, password: password) { AuthDataResult, error in
            if let error = error {
                print(("error al crear nuevo usuario\(error.localizedDescription)"))
                completionBlock(.failure(error))
                return
            }
            let email = AuthDataResult?.user.email ?? "no email"
            print("Nuevo User crado con informacion\(email)")
            completionBlock(.success(.init(email: email)))
        }
    }
    //Firebase
    func login(email: String, password: String, completionBlock: @escaping (Result<User, Error>) -> Void) {
        Auth.auth().signIn(withEmail: email, password: password) { AuthDataResult, error in
            if let error = error {
                print(("error de login\(error.localizedDescription)"))
                completionBlock(.failure(error))
                return
            }
            let email = AuthDataResult?.user.email ?? "no email"
            print("Nuevo User login con informacion\(email)")
            completionBlock(.success(.init(email: email)))
        }
    }
    
    //Facebook
    func loginWithFacebook(completionBlock: @escaping (Result<User,Error>) -> Void) {
        facebookAuthentication.loginFacebook { result in
            switch result {
            case .success(let accessToken):
                let credetial = FacebookAuthProvider.credential(withAccessToken: accessToken)
                Auth.auth().signIn(with: credetial) { AuthDataResult, error in
                    if let error = error {
                        print("\(error.localizedDescription)")
                        completionBlock(.failure(error))
                        return
                    }
                    let email = AuthDataResult?.user.email ?? "No email"
                    print("nuevo usuario creado con info\(email)")
                    completionBlock(.success(.init(email: email)))
                }
            case .failure(let error):
                print("error al logiar con facebook\(error.localizedDescription)")
                completionBlock(.failure(error))
            }
            
        }
    }
 
    func logout() throws {
        try Auth.auth().signOut()
    }
}
