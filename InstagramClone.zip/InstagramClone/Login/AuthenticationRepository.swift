//
//  AuthenticationRepository.swift
//  InstagramClone
//
//  Created by Luciano Nicolini on 28/10/2022.
//

import Foundation

final class AuthenticationRepository {
    private let AuthenticatiodataSource: AuthenticationDataSource
   
    init(AuthenticatiodataSource: AuthenticationDataSource = AuthenticationDataSource()) {
        self.AuthenticatiodataSource = AuthenticatiodataSource
    }
    
    func getCurrentUser() -> User? {
        AuthenticatiodataSource.getCurrentUser()
    }
    
    func creatennewUser(email: String, password: String, completionBlock: @escaping (Result<User, Error>) -> Void) {
        AuthenticatiodataSource.createNewUser(email: email, password: password, completionBlock: completionBlock)
    }
    
    func login(email: String, password: String, completionBlock: @escaping (Result<User, Error>) -> Void) {
        AuthenticatiodataSource.login(email: email, password: password, completionBlock: completionBlock)
    }
    
    //Facebook
    func loginFacebook(completionBlock: @escaping (Result<User, Error>) -> Void) {
        AuthenticatiodataSource.loginWithFacebook(completionBlock: completionBlock)
    }
    
    func logout() throws {
        try AuthenticatiodataSource.logout()
    }
}

