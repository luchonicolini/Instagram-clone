//
//  AuthenticationViewModel.swift
//  InstagramClone
//
//  Created by Luciano Nicolini on 28/10/2022.
//

import Foundation

final class AuthenticationViewModel: ObservableObject {
    @Published var user:User?
    @Published var messangeError: String?
    private let authenticationRepository: AuthenticationRepository
    
    func getCurrentUser() {
        self.user = authenticationRepository.getCurrentUser()
        getCurrentUser()
    }
    
    init(authenticationRepository: AuthenticationRepository = AuthenticationRepository()) {
        self.authenticationRepository = authenticationRepository
    }
    
    func createNewUser(email: String,password: String) {
        authenticationRepository.creatennewUser(email: email, password: password) { [weak self] result in
            switch result {
            case .success(let user):
                self?.user = user
            case .failure(let error):
                self?.messangeError = error.localizedDescription
            }
        }
    }
 
    //Firebase
    func login(email: String,password: String) {
        authenticationRepository.login(email: email, password: password) { [weak self] result in
            switch result {
            case .success(let user):
                self?.user = user
            case .failure(let error):
                self?.messangeError = error.localizedDescription
            }
        }
    }
    
    //Facebook
    func loginFacebook() {
        authenticationRepository.loginFacebook() { [weak self] result in
            switch result {
            case .success(let user):
                self?.user = user
            case .failure(let error):
                self?.messangeError = error.localizedDescription
            }
        }
    }
    
    func logout() {
        do {
            try authenticationRepository.logout()
            self.user = nil
        } catch {
            print("error")
        }
    }
}

