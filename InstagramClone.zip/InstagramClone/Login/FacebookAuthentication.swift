//
//  FacebookAuthentication.swift
//  InstagramClone
//
//  Created by Luciano Nicolini on 01/11/2022.
//

import Foundation
import FacebookLogin

final class FacebookAuthentication {
    let loginManager = LoginManager()
    func loginFacebook(completionBlock: @escaping (Result<String,Error>) -> Void) {
        loginManager.logIn(permissions: ["email"], from: nil) { LoginManagerLoginResult, error in
            if let error = error {
                print("error login with Facebook\(error.localizedDescription)")
                completionBlock(.failure(error))
                return
            }
            let token = LoginManagerLoginResult?.token?.tokenString
            completionBlock(.success(token ?? "Token Vacio"))
        }
        
    }
}
