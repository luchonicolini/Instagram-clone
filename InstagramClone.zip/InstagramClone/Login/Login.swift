//
//  Login.swift
//  InstagramClone
//
//  Created by Luciano Nicolini on 26/10/2022.
//

import SwiftUI
import FirebaseAuth

struct Login: View {
    @ObservedObject var authenticacionViewModel: AuthenticationViewModel
   
    @State private var isShowingSheet = false
    @State private var email: String = ""
    @State private var password: String = ""
    @State private var editingEmailTextfield: Bool = false
    @State private var editingPasswordTextfield: Bool = false
    
    var body: some View {
        ZStack {
            Color("background").edgesIgnoringSafeArea(.all)
            VStack {
                Image("logo.svg")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 200,height: 100)
                
                //Email
                HStack(spacing: 12.0) {
                    TextField("Telefono, usuario o correo electronico", text: $email) { isEditing in
                        editingEmailTextfield = isEditing
                        editingPasswordTextfield = false
                    }
                    .foregroundColor(Color("primary"))
                    .autocapitalization(.none)
                    .textContentType(.emailAddress)
                    .keyboardType(.emailAddress)
                }
                .padding(.horizontal)
                .frame(width: 360,height: 49) //ancho-barra
                .background(
                    Color("ColorBarras")
                        .cornerRadius(5)
                        .opacity(0.8)
                )
                //Password
                HStack(spacing: 12.0) {
                    SecureField("Contraseña", text: $password) {
                        editingPasswordTextfield = false
                    }
                    .foregroundColor(Color("primary"))
                    .autocapitalization(.none)
                    .textContentType(.password)
                }
                .padding(.horizontal)
                .frame(width: 360,height: 49) //ancho-barra
                .background(
                    Color("ColorBarras")
                        .cornerRadius(5)
                        .opacity(0.8)
                )
                //botones
                
                HStack {
                    Button(action: {}, label: {
                        Text("¿Olvidaste la contraseña?")
                            .foregroundColor(Color("Texto"))
                    })
                }
                .font(.system(size: 13))
                .frame(maxWidth: .infinity,alignment: .trailing)
                .padding(.horizontal,14)
                //boton inicio
                Button(action: {
                    authenticacionViewModel.login(email: email, password: password)
                }, label: {
                    HStack {
                        Text("Iniciar sesion")
                            .foregroundColor(.white)
                            .font(.system(size: 15))
                    }
                    .modifier(Buttons())
                })
                
                HStack {
                    Button(action: {
                        authenticacionViewModel.loginFacebook()
                    }, label: {
                        Image("fb")
                            .resizable()
                            .frame(width: 23, height: 23)
                        Text("Iniciar sesion con Facebook").bold()
                            .foregroundColor(Color("Texto"))
                            
                        
                    })
                }
                .font(.system(size: 14))
                .frame(maxWidth: .infinity,alignment: .center)
                .padding(.horizontal,14)
                .padding(.top,15)
                
                //error login
                if let messagerError = authenticacionViewModel.messangeError {
                    Text(messagerError)
                        .bold()
                        .font(.body)
                        .foregroundColor(.red)
                        .padding(.top,20)
                }
                Spacer()
                Divider()
                HStack {
                    Text("¿No Tines una cuenta?")
                        .font(.caption)
                        .foregroundColor(.secondary)
                    Button(action: {
                        isShowingSheet.toggle()
                    }, label: {
                        Text("Registrate")
                            .font(.caption)
                            .foregroundColor(Color("Texto"))
                        
                    })
                   
                    .sheet(isPresented: $isShowingSheet) {
                        Register(authenticacionViewModel: authenticacionViewModel)
                        
                    }
                }
            }
        }
    }
}

struct Login_Previews: PreviewProvider {
    static var previews: some View {
        Login(authenticacionViewModel: AuthenticationViewModel())
    }
}
