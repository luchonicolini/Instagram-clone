//
//  Register.swift
//  InstagramClone
//
//  Created by Luciano Nicolini on 28/10/2022.
//

import SwiftUI

struct Register: View {
    
    @ObservedObject var authenticacionViewModel: AuthenticationViewModel
    @State private var email: String = ""
    @State private var password: String = ""
    @State private var editingEmailTextfield: Bool = false
    @State private var editingPasswordTextfield: Bool = false
    
    var body: some View {
        ZStack {
            Color("background").edgesIgnoringSafeArea(.all)
            VStack {
                Image("logo.svg")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 200,height: 100)
                
                //Email
                HStack(spacing: 12.0) {
                    TextField("Telefono, usuario o correo electronico", text: $email) { isEditing in
                        editingEmailTextfield = isEditing
                        editingPasswordTextfield = false
                    }
                    .foregroundColor(Color("primary"))
                    .autocapitalization(.none)
                    .textContentType(.emailAddress)
                    .keyboardType(.emailAddress)
                }
                .padding(.horizontal)
                .frame(width: 360,height: 49) //ancho-barra
                .background(
                    Color("ColorBarras")
                        .cornerRadius(5)
                        .opacity(0.8)
                )
                //Password
                HStack(spacing: 12.0) {
                    SecureField("Contraseña", text: $password) {
                        editingPasswordTextfield = false
                    }
                    .foregroundColor(Color("primary"))
                    .autocapitalization(.none)
                    .textContentType(.password)
                }
                .padding(.horizontal)
                .frame(width: 360,height: 49) //ancho-barra
                .background(
                    Color("ColorBarras")
                        .cornerRadius(5)
                        .opacity(0.8)
                )
                
                //PasswordConfirmation
                HStack(spacing: 12.0) {
                    SecureField("Confirmar contraseña", text: $password) {
                        editingPasswordTextfield = false
                    }
                    .foregroundColor(Color("primary"))
                    .autocapitalization(.none)
                    .textContentType(.password)
                }
                .padding(.horizontal)
                .frame(width: 360,height: 49) //ancho-barra
                .background(
                    Color("ColorBarras")
                        .cornerRadius(5)
                        .opacity(0.8)
                )
         
                //boton inicio
                Button(action: {
                    authenticacionViewModel.createNewUser(email: email, password: password)
                }, label: {
                    HStack {
                        Text("Iniciar sesion")
                            .foregroundColor(.white)
                            .font(.system(size: 15))
                    }
                    .modifier(Buttons())
                })
            }
        }
    }
}


struct Register_Previews: PreviewProvider {
    static var previews: some View {
        Register(authenticacionViewModel: AuthenticationViewModel())
    }
}

