//
//  ViewModel.swift
//  InstagramClone
//
//  Created by Luciano Nicolini on 25/10/2022.
//

import Foundation
import SwiftUI

class viewModel : ObservableObject {
    @Published var timelineList = [TimelineModel]()
    @Published var storyList = [StoryModel]()
  
    internal init(timelineList: [TimelineModel] = [TimelineModel](), storyList: [StoryModel] = [StoryModel]()) {
        self.timelineList = TimelineModel.getPosts()
        self.storyList = StoryModel.getStories()
    }
}
