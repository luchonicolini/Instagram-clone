//
//  HomeView.swift
//  InstagramClone
//
//  Created by Luciano Nicolini on 25/10/2022.
//

import SwiftUI

struct HomeView: View {
    @ObservedObject private var viewmodel = viewModel()
    @ObservedObject var authenticacionViewModel = AuthenticationViewModel()
    init(){
        let appearance = UINavigationBarAppearance()
        appearance.configureWithOpaqueBackground()
        appearance.backgroundColor = UIColor(named: "tabBar-bg")
        
        UINavigationBar.appearance().standardAppearance = appearance
        UINavigationBar.appearance().compactAppearance = appearance
        UINavigationBar.appearance().scrollEdgeAppearance = appearance
    }
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                Divider().overlay(Color("primary")).frame(height: 1).opacity(0.4)
                ScrollView {
                    VStack {
                        storyList
                        Divider().overlay(Color("primary")).frame(height: 1).opacity(0.4)
                        
                        ForEach(viewmodel.timelineList) { timeline in
                            TimelineView(timeline: timeline)
                        }
                        Color.clear.padding(.bottom, 20)
                        
                    }
                    .toolbar {
                        self.toolbarView()
                    }
                }
                .navigationBarTitleDisplayMode(.inline)
            }
        }
    }
    
    //Navigation
    @ToolbarContentBuilder
    func toolbarView() -> some ToolbarContent {
     
        
        ToolbarItem(placement: .navigationBarLeading) {
            Image("instagram-logo")
                .renderingMode(.template)
                .foregroundColor(Color("primary"))
        }
        
        ToolbarItem(placement: .navigationBarTrailing) {
            Button(action: {}) {
                Image("camera-Icon")
                    .renderingMode(.template)
                    .foregroundColor(Color("primary"))
            }
        }
        
        ToolbarItem(placement: .navigationBarTrailing) {
            HStack{
                Button(action: {}) {
                    Image("igtv")
                        .renderingMode(.template)
                        .foregroundColor(Color("primary"))
                }
                Button(action: {}) {
                    Image("messanger")
                        .renderingMode(.template)
                        .foregroundColor(Color("primary"))
                }
            }
        }
    }
    var storyList : some View {
        ScrollView(.horizontal,showsIndicators: false) {
            HStack {
                ForEach(viewmodel.storyList) { item in
                    StoryView(story: item)
                }
            }
            .padding(.leading,10)
            .padding(.vertical,8)
        }
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
