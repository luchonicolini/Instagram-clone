//
//  TimelineView.swift
//  InstagramClone
//
//  Created by Luciano Nicolini on 25/10/2022.
//

import SwiftUI

struct TimelineView: View {
    @State private var comment = ""
    @State private var date: String = ""
    
    let timeline: TimelineModel
    var body: some View {
        VStack {
           hedederView
           postImage
           actionIcon
           likeSection
           commentSection
           comentario
         
         
            
            
        }
    }
    
    var hedederView: some View {
        HStack() {
            Image(timeline.user.profilePicture)
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(width: 32,height: 32)
                .clipShape(Circle())
            VStack(alignment: .leading, spacing: 2) {
                HStack {
                    Text(timeline.user.username)
                        .font(.system(size: 13,weight: .bold))
                    if timeline.user.isVerified {
                        Image("official-icon")
                            .resizable()
                            .frame(width: 10,height: 10)
                    } else {
                        
                    }
                    
                }
                Text(timeline.user.city)
                    .font(.system(size: 11))
            }
            Spacer()
            Button(action: {
                
            }, label: {
                Image("more-icon")
                    .renderingMode(.template)
                    .foregroundColor(Color("primary"))
                    
            })
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.horizontal,14)
    }
    var postImage: some View {
        Image(timeline.photo)
            .resizable()
            .frame(height: UIScreen.main.bounds.width)
            .frame(maxWidth: .infinity)
            .aspectRatio(contentMode: .fill)
    }
    var actionIcon: some View {
        HStack(spacing: 17) {
            Button(action: {}, label: {
                Image("like")
                    .renderingMode(.template)
                    .foregroundColor(Color("primary"))
            })
            Button(action: {}, label: {
                Image("comment")
                    .renderingMode(.template)
                    .foregroundColor(Color("primary"))
            })
            Button(action: {}, label: {
                Image("messanger")
                    .renderingMode(.template)
                    .foregroundColor(Color("primary"))
            })
            Spacer()
            Button(action: {}, label: {
                Image("save")
                    .renderingMode(.template)
                    .foregroundColor(Color("primary"))
            })
            
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.horizontal,14)
    }
    var likeSection: some View {
        HStack {
            Image(UserModel.getUsers().randomElement()!.profilePicture)
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(width: 17,height: 17)
                .clipShape(Circle())
            Text("liked by")
            + Text(UserModel.getUsers().randomElement()!.username).bold()
            + Text(" and ")
            + Text("44,000").bold()
            + Text(" others").bold()
        }
        .font(.system(size: 13))
        .frame(maxWidth: .infinity,alignment: .leading)
        .padding(.horizontal,14)

    }
    var commentSection: some View {
        HStack {
            Text(timeline.user.username).bold()
            + Text("\(CommentsModel.getComments().randomElement()!.comment)")
            
        }
        .font(.system(size: 13))
        .frame(maxWidth: .infinity,alignment: .leading)
        .padding(.horizontal,14)
        
    }
    
    var comentario: some View {
        VStack(spacing: 6) {
            HStack() {
                Image(timeline.user.profilePicture)
                    .resizable()
                    .frame(width: 24,height: 24)
                    .cornerRadius(50)
                TextField("Add comment...", text: $comment)
                    .font(.caption)
                    .foregroundColor(Color("primary"))
            }
            //..
            
            VStack() {
                Text("Hace \(date) minutos")
                    .font(.caption2)
                    .foregroundColor(Color.secondary)
            }
            .onAppear() {
                date =
                Date.now.formatted(.dateTime.minute().locale(Locale(identifier: "es-AR")))
               
            }
            .frame(maxWidth: .infinity,alignment: .leading)
            
            
        }
        .frame(maxWidth: .infinity,alignment: .leading)
        .padding(.horizontal,14)
    }
}

struct TimeLineView_Previews: PreviewProvider {
    static var previews: some View {
        TimelineView(timeline: TimelineModel.getPosts()[0])
    }
}
